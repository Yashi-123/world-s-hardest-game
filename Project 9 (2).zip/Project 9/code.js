var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["7602d40c-15d5-45a7-958c-aacb7112101b","8e23a148-bb51-4627-ba13-30c468ef6b2c","09f68bb5-a274-4a96-ad8c-d4a590b07c29","f97d690a-e355-429a-bef6-7f33c2e64c6d","ea02d33e-5fbf-4bd7-9285-b74a605a786e","8dddcbc2-5fdd-453e-9aa7-27ebed99b3ec","b6a3b271-c53b-4a35-bb1e-526ae6449697"],"propsByKey":{"7602d40c-15d5-45a7-958c-aacb7112101b":{"name":"basketball_1","sourceUrl":null,"frameSize":{"x":50,"y":50},"frameCount":1,"looping":true,"frameDelay":12,"version":"0FadVsNJ3Fx3lRZREnWRSdfWJFnLdK..","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":50},"rootRelativePath":"assets/7602d40c-15d5-45a7-958c-aacb7112101b.png"},"8e23a148-bb51-4627-ba13-30c468ef6b2c":{"name":"lucy","sourceUrl":null,"frameSize":{"x":15,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"PqyqDxTADhWtCFWCv.8_cRo_6pBEkeqG","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":15,"y":30},"rootRelativePath":"assets/8e23a148-bb51-4627-ba13-30c468ef6b2c.png"},"09f68bb5-a274-4a96-ad8c-d4a590b07c29":{"name":"monster1","sourceUrl":null,"frameSize":{"x":25,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"_Z2GUuCkTVrn_VRtPhBBDskHuK8b4.Px","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":25,"y":30},"rootRelativePath":"assets/09f68bb5-a274-4a96-ad8c-d4a590b07c29.png"},"f97d690a-e355-429a-bef6-7f33c2e64c6d":{"name":"monster2","sourceUrl":null,"frameSize":{"x":25,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"BAlDr8D_rvxwJuzJ2bktfzp0VhAK1HRe","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":25,"y":30},"rootRelativePath":"assets/f97d690a-e355-429a-bef6-7f33c2e64c6d.png"},"ea02d33e-5fbf-4bd7-9285-b74a605a786e":{"name":"monster3","sourceUrl":null,"frameSize":{"x":25,"y":25},"frameCount":1,"looping":true,"frameDelay":12,"version":"23sWAgRjJzB5LcDZrJTBDjIWQhbf59nT","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":25,"y":25},"rootRelativePath":"assets/ea02d33e-5fbf-4bd7-9285-b74a605a786e.png"},"8dddcbc2-5fdd-453e-9aa7-27ebed99b3ec":{"name":"monster4","sourceUrl":null,"frameSize":{"x":30,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"vNcueOXjkwRFtd8uRrmoBoDbPFkyDJl0","categories":["faces"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":30,"y":30},"rootRelativePath":"assets/8dddcbc2-5fdd-453e-9aa7-27ebed99b3ec.png"},"b6a3b271-c53b-4a35-bb1e-526ae6449697":{"name":"monster5","sourceUrl":null,"frameSize":{"x":30,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"pk6lynB0qfLYoEtDnHB5FHX4HD2AqPLX","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":30,"y":30},"rootRelativePath":"assets/b6a3b271-c53b-4a35-bb1e-526ae6449697.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

//creating the player lucy
var lucy = createSprite(20, 40, 18, 18);
lucy.setAnimation("lucy");

var monster1 = createSprite(20, 110, 18, 18);
monster1.setAnimation("monster1");

var monster2 = createSprite(210, 260, 18, 18);
monster2.setAnimation("monster2");

var monster3 = createSprite(210, 200, 18, 18);
monster3.setAnimation("monster3");

var monster4 = createSprite(210, 365, 18, 18);
monster4.setAnimation("monster4");

var monster5 = createSprite(290, 25, 18, 18);
monster5.setAnimation("monster5");

var life = 0;



//creating the maze walls (wall1 - wall2)
var wall1  = createSprite(10, 70, 100 , 20); 
wall1.shapeColor="brown";
var wall2 = createSprite(100, 50, 20, 100);
wall2.shapeColor="brown";
var wall3 = createSprite(80, 140, 100, 20);
wall3.shapeColor="brown";
var wall4 = createSprite(150, 20, 80, 20 );
wall4.shapeColor="brown";
var wall5 = createSprite(160, 140, 20, 100);
wall5.shapeColor="brown";
var wall6 = createSprite(250, 70, 20, 100);
wall6.shapeColor="brown";
var wall7 = createSprite(320, 50, 80, 20);
wall7.shapeColor="brown";
var wall8 = createSprite(270, 150, 100, 20);
wall8.shapeColor="brown";
var wall9 = createSprite(340, 130, 20, 100);
wall9.shapeColor="brown";
var wall10 = createSprite(100, 220, 100, 20);
wall10.shapeColor="brown";
var wall11 = createSprite(20, 300, 20,100);
wall11.shapeColor="brown";
var wall12 = createSprite(80, 300, 100, 20);
wall12.shapeColor="brown";
var wall13 = createSprite(160, 320, 20, 80);
wall13.shapeColor="brown";
var wall14 = createSprite(100, 355, 20, 80);
wall14.shapeColor="brown";
var wall15 = createSprite(260, 265, 20, 110);
wall15.shapeColor="brown";
var wall16 = createSprite(210, 310, 80, 20);
wall16.shapeColor="brown";
var wall17 = createSprite(200, 220, 100, 20 );
wall17.shapeColor="brown";
var wall18 = createSprite(350, 220, 100, 20);
wall18.shapeColor="brown";
var wall19 = createSprite(365, 280, 70, 20);
wall19.shapeColor="brown";
var wall20 = createSprite(320, 300, 20, 90);
wall20.shapeColor="brown";
var wall21 = createSprite(260, 390, 130, 20);
wall21.shapeColor="brown";
var wall22 = createSprite(360, 368, 10, 60);
wall22.shapeColor="brown";

//create Gate
var Gate = createSprite(395, 368, 10, 50);
Gate.shapeColor="yellow";

monster1.velocityX=3;
monster2.velocityX=5;
monster3.velocityX=8;
monster4.velocityX=6;
monster5.velocityX=5;

  function draw() {
    
  background("pink");
    
  text("lucy", 15, 15);
  text("Gate", 365, 370); 
  

  
createEdgeSprites();
lucy.collide(edges);
lucy.collide(wall1);
lucy.collide(wall2);
lucy.collide(wall3);
lucy.collide(wall4);                                             
lucy.collide(wall5);
lucy.collide(wall6);
lucy.collide(wall7);
lucy.collide(wall8);
lucy.collide(wall9);
lucy.collide(wall10);
lucy.collide(wall11);
lucy.collide(wall12);
lucy.collide(wall13);
lucy.collide(wall14);
lucy.collide(wall15);
lucy.collide(wall16);
lucy.collide(wall17);
lucy.collide(wall18);
lucy.collide(wall19);
lucy.collide(wall20); 
lucy.collide(wall21); 
lucy.collide(wall22);
lucy.collide(Gate);

monster1.bounceOff(wall2);
monster1.bounceOff(leftEdge);
monster2.bounceOff(wall15);
monster2.bounceOff(wall11);
monster3.bounceOff(edges);
monster4.bounceOff(wall22);
monster4.bounceOff(wall13);
monster5.bounceOff(wall6);
monster5.bounceOff(rightEdge);

 if (lucy.isTouching(Gate))
 {
  text("You Win",30,15)  
  }
   
  if (keyDown(LEFT_ARROW))
  {
    lucy.x=lucy.x-3
  }
  if (keyDown(RIGHT_ARROW)) 
  {
    lucy.x=lucy.x+3
  }
   if (keyDown(UP_ARROW)) 
   {
     lucy.y=lucy.y-3
   
  }
   if (keyDown(DOWN_ARROW)) 
   {
    lucy.y=lucy.y+3
  }
  
 if (lucy.isTouching(monster1)|| lucy.isTouching(monster2)|| lucy.isTouching(monster3|| lucy.isTouching(monster4))) 
 {
  
    lucy.x=18;
    lucy.y=33;
  }
 
  drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
